Hi! 

To run our code, please follow the next steps:

IF YOU ARE USING GOOGLE COLLAB:

1 - Import the python code file (.ipynb) to google collab
2 - Click on 'run all'
3 - You will be asked to choose a file, please choose day.csv

IF YOU ARE NOT USING GOOGLE COLLAB:

1 - Open the python code file (.ipynb) using your IDE
2 - Delete the first block of code
3 - In the second block of code (which is now the first), please:
    - Put a comment or delete line: df = pd.read_csv("/content/day.csv")
    - Uncomment the line: # df = pd.read_csv("day.csv")
4 - Click on 'run all'

Thank you and happy grading!
